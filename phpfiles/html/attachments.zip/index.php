<!DOCTYPE html>
<html>
<head>
<title>
Online Library Management System
</title>
<link rel="stylesheet" type="text/css" href="style.css"> 
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

</head>
<body>
  <div class="wrapper">

       <header>
	   <div class="logo">
	   <img src="images/10.jpg" height="80px" width="90px">
	   <h1 style="color:white">ONLINE LIBRARY MANAGEMENT SYSTEM</h1>
	   </div>
	        <nav>
			<ul>
			<li><a href="index.php">HOME</a></li>
			<li><a href="books.php">BOOKS</a></li>
			<li><a href="student login page.php">STUDENT_LOGIN</a></li>
			
			<li><a href="feedback.php">FEEDBACK</a></li>
			</ul>
	   
	        </nav>
       </header>
       <section>
	   
	   <br><br><br>
            <div class="box">
			<br><br><br><br><br><br><br>
			<h1 style="text-align:center; text-shadow:2px 6px 2px blue;; color:white; font-size:50px; font-family:gabriola; font-style:bold;  ">Welcome to library</h1><br><br>
			 
			 
			</div>
			
       </section>
        <footer>
		<p style="color:white; text-align:center;">
		<br>
		Email:&nbsp S160734@rguktsklm.ac.in <br>
		        S161206@rguktsklm.ac.in <br><br>
	    Mobile:&nbsp +918096*******
		</p>
        </footer>
   <div>
</body>


</html>